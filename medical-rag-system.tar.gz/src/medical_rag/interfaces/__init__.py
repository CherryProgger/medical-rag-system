"""
Интерфейсы для медицинской RAG системы
"""

from .web_interface import create_web_app

__all__ = ["create_web_app"]
