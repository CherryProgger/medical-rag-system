"""
Сервисы для медицинской RAG системы
"""

from .evaluation_service import EvaluationService

__all__ = ["EvaluationService"]
